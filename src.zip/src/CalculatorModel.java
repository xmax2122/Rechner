import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;

public class CalculatorModel {

    private double firstNumber = 0;
    private String currentOperator = "";
    private boolean isStartNewInput = true;
    private final List<String> history = new ArrayList<>();
    private final DecimalFormat formatter;

    public CalculatorModel() {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');

        this.formatter = new DecimalFormat("#,##0.######", symbols);
    }

    private double parseSafeDouble(String text) {
        if (text == null || text.isEmpty() || text.equals("Error") || text.equals("-") || text.matches("[+\\-*/]")) {
            return 0;
        }
        String cleanText = text.replace(".", "").replace(",", ".");
        try {
            return Double.parseDouble(cleanText);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public String processNumber(String currentText, String number) {
        if (isStartNewInput || currentText.equals("0")) {
            isStartNewInput = false;

            if (number.equals(".") || number.equals(",")) {
                return "0,";
            }
            return number;
        } else if (currentText.matches("[+*/]")) {
            isStartNewInput = false;
            if (number.equals(".") || number.equals(",")) {
                return "0,";
            }
            return number;
        } else if (currentText.equals("-")) {
            if (number.equals(".") || number.equals(",")) {
                return "-0,";
            }
            return "-" + number;
        } else {
            if ((number.equals(".") || number.equals(",")) && currentText.contains(",")) {
                return currentText;
            }

            String inputSymbol = (number.equals(".") || number.equals(",")) ? "," : number;

            if (!inputSymbol.equals(",")) {
                String raw = (currentText + inputSymbol).replace(".", "");
                if (!raw.contains(",")) {
                    double val = parseSafeDouble(raw);
                    return formatter.format(val);
                }
            }
            return currentText + inputSymbol;
        }
    }

    public String processOperator(String currentText, String operator) {
        if (operator.equals("-") && (isStartNewInput || currentText.equals("0") || currentText.matches("[+*/]"))) {
            isStartNewInput = false;
            return "-";
        }

        if (currentText.matches("[+\\-*/]")) {
            currentOperator = operator;
            return operator;
        }

        if (!currentOperator.isEmpty() && !isStartNewInput) {
            currentText = calculate(currentText);
        }

        firstNumber = parseSafeDouble(currentText);
        currentOperator = operator;
        isStartNewInput = true;

        return operator;
    }

    public String calculate(String currentText) {
        if (currentOperator.isEmpty() || currentText.matches("[+\\-*/]") || currentText.equals("-")) {
            return currentText;
        }

        double secondNumber = parseSafeDouble(currentText);
        double result = 0;

        switch (currentOperator) {
            case "+" -> result = firstNumber + secondNumber;
            case "-" -> result = firstNumber - secondNumber;
            case "*" -> result = firstNumber * secondNumber;
            case "/" -> {
                if (secondNumber == 0) {
                    currentOperator = "";
                    isStartNewInput = true;
                    return "Error";
                }
                result = firstNumber / secondNumber;
            }
        }

        String historyEntry = String.format("%s %s %s = %s",
                formatter.format(firstNumber), currentOperator, formatter.format(secondNumber), formatResult(result));
        history.add(historyEntry);

        currentOperator = "";
        isStartNewInput = true;

        return formatResult(result);
    }

    public String processUnaryOperator(String currentText, String operator) {
        if (currentText.matches("[+\\-*/]") || currentText.equals("-"))
            return currentText;

        double number = parseSafeDouble(currentText);
        double result = 0;

        if (operator.equals("√")) {
            if (number < 0)
                return "Error";
            result = Math.sqrt(number);
            history.add(String.format("√(%.2f) = %s", number, formatResult(result)));
        }

        isStartNewInput = true;
        return formatResult(result);
    }

    public void clear() {
        firstNumber = 0;
        currentOperator = "";
        isStartNewInput = true;
    }

    public List<String> getHistory() {
        return history;
    }

    private String formatResult(double result) {
        return formatter.format(result);
    }
}