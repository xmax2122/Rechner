import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class CalculatorController {

    private final CalculatorModel model;
    private final CalculatorView view;

    public CalculatorController(CalculatorModel model, CalculatorView view) {
        this.model = model;
        this.view = view;

        this.view.setButtonListener(new ButtonClickListener());
        setupKeyboardSupport();
    }

    private void handleCommand(String command) {
        String currentDisplay = view.getDisplayField();

        switch (command) {
            case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "," -> {
                String updated = model.processNumber(currentDisplay, command);
                view.setDisplayField(updated);
            }
            case "+", "-", "*", "/" -> {
                String updated = model.processOperator(currentDisplay, command);
                view.setDisplayField(updated);
            }
            case "=" -> {
                String result = model.calculate(currentDisplay);
                view.setDisplayField(result);
                view.updateHistory(model.getHistory());
            }
            case "√" -> {
                String result = model.processUnaryOperator(currentDisplay, "√");
                view.setDisplayField(result);
                view.updateHistory(model.getHistory());
            }
            case "C" -> {
                model.clear();
                view.setDisplayField("0");
            }
            case "Del" -> {
                if (currentDisplay.matches("[+\\-*/]") || currentDisplay.length() <= 1 || currentDisplay.equals("Error")) {
                    view.setDisplayField("0");
                } else {
                    view.setDisplayField(currentDisplay.substring(0, currentDisplay.length() - 1));
                }
            }
            case "Random" -> {
                int randomNum = (int) (Math.random() * 100) + 1;
                view.setDisplayField(String.valueOf(randomNum));
            }
        }
    }

    private class ButtonClickListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton button = (JButton) e.getSource();
            handleCommand(button.getText());
        }
    }

    private void setupKeyboardSupport() {
        JRootPane root = view.getRootPane();
        InputMap inputMap = root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap actionMap = root.getActionMap();

        Object[][] keyBindings = {
            {"0", KeyStroke.getKeyStroke(KeyEvent.VK_0, 0)},
            {"1", KeyStroke.getKeyStroke(KeyEvent.VK_1, 0)},
            {"2", KeyStroke.getKeyStroke(KeyEvent.VK_2, 0)},
            {"3", KeyStroke.getKeyStroke(KeyEvent.VK_3, 0)},
            {"4", KeyStroke.getKeyStroke(KeyEvent.VK_4, 0)},
            {"5", KeyStroke.getKeyStroke(KeyEvent.VK_5, 0)},
            {"6", KeyStroke.getKeyStroke(KeyEvent.VK_6, 0)},
            {"7", KeyStroke.getKeyStroke(KeyEvent.VK_7, 0)},
            {"8", KeyStroke.getKeyStroke(KeyEvent.VK_8, 0)},
            {"9", KeyStroke.getKeyStroke(KeyEvent.VK_9, 0)},

            {"0", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD0, 0)},
            {"1", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD1, 0)},
            {"2", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD2, 0)},
            {"3", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD3, 0)},
            {"4", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD4, 0)},
            {"5", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD5, 0)},
            {"6", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD6, 0)},
            {"7", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD7, 0)},
            {"8", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD8, 0)},
            {"9", KeyStroke.getKeyStroke(KeyEvent.VK_NUMPAD9, 0)},

            {"+", KeyStroke.getKeyStroke(KeyEvent.VK_ADD, 0)},
            {"+", KeyStroke.getKeyStroke(KeyEvent.VK_PLUS, 0)},
            {"-", KeyStroke.getKeyStroke(KeyEvent.VK_SUBTRACT, 0)},
            {"-", KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, 0)},
            {"*", KeyStroke.getKeyStroke(KeyEvent.VK_MULTIPLY, 0)},
            {"/", KeyStroke.getKeyStroke(KeyEvent.VK_DIVIDE, 0)},
            {"/", KeyStroke.getKeyStroke(KeyEvent.VK_SLASH, 0)},

            {".", KeyStroke.getKeyStroke(KeyEvent.VK_DECIMAL, 0)},
            {".", KeyStroke.getKeyStroke(KeyEvent.VK_PERIOD, 0)},
            {",", KeyStroke.getKeyStroke(KeyEvent.VK_COMMA, 0)},

            {"=", KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0)},  
            {"=", KeyStroke.getKeyStroke(KeyEvent.VK_EQUALS, 0)}, 
            {"Del", KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SPACE, 0)},
            {"C", KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0)}
        };

        for (int i = 0; i < keyBindings.length; i++) {
            String command = (String) keyBindings[i][0];
            KeyStroke keyStroke = (KeyStroke) keyBindings[i][1];
            String mapKey = "KEY_ACTION_" + i;

            inputMap.put(keyStroke, mapKey);
            actionMap.put(mapKey, new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    handleCommand(command);
                }
            });
        }
    }
}