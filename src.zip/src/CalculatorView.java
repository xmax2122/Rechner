import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorView {

    private JFrame window;
    private JPanel colum1, colum2, colum3, colum4, colum5;
    private JPanel calcPanel, historyPanel, buttonPanel, historyContainer;
    private JTextArea historyField;
    private JTextField displayField;
    private JButton toggleHistoryBtn;

    public CalculatorView() {
        window = new JFrame("Rechner");
        window.setLayout(new BorderLayout());
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(750, 500);

        colum1 = new JPanel(new GridLayout(4, 1, 8, 8));
        colum2 = new JPanel(new GridLayout(4, 1, 8, 8));
        colum3 = new JPanel(new GridLayout(4, 1, 8, 8));
        colum4 = new JPanel(new GridLayout(4, 1, 8, 8));
        colum5 = new JPanel(new GridLayout(4, 1, 8, 8));

        buttonPanel = new JPanel(new GridLayout(1, 5, 8, 8));
        calcPanel = new JPanel(new BorderLayout(8, 8));

        historyPanel = new JPanel(new BorderLayout());
        historyPanel.setPreferredSize(new Dimension(240, 0));
        historyPanel.setMinimumSize(new Dimension(0, 0));

        historyField = new JTextArea("History:\n");
        historyField.setEditable(false);
        historyField.setFocusable(false);
        historyField.setFont(new Font("Arial", Font.PLAIN, 16));
        historyField.setMargin(new Insets(8, 8, 8, 8));

        JScrollPane scrollPane = new JScrollPane(historyField);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setMinimumSize(new Dimension(0, 0));
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        scrollPane.putClientProperty("FlatLaf.style", "arc: 20");
        historyPanel.add(scrollPane, BorderLayout.CENTER);

        toggleHistoryBtn = new JButton("📜");
        toggleHistoryBtn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        toggleHistoryBtn.setFocusPainted(false);
        toggleHistoryBtn.putClientProperty("FlatLaf.style", "arc: 999");
        toggleHistoryBtn.setBackground(new Color(60, 64, 67));
        toggleHistoryBtn.setForeground(Color.WHITE);
        toggleHistoryBtn.setPreferredSize(new Dimension(40, 40));

        historyContainer = new JPanel(new BorderLayout(5, 5));

        JPanel btnWrapper = new JPanel(new GridBagLayout());
        btnWrapper.add(toggleHistoryBtn);

        historyContainer.add(btnWrapper, BorderLayout.WEST);
        historyContainer.add(historyPanel, BorderLayout.CENTER);

        toggleHistoryBtn.addActionListener(new ActionListener() {
            private Timer timer;
            private boolean isExpanded = true;
            private final int MAX_WIDTH = 240;
            private int currentWidth = MAX_WIDTH;

            @Override
            public void actionPerformed(ActionEvent e) {
                if (timer != null && timer.isRunning())
                    return;

                timer = new Timer(8, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ev) {
                        if (isExpanded) {
                            currentWidth -= 20;
                            if (currentWidth <= 0) {
                                currentWidth = 0;
                                isExpanded = false;
                                ((Timer) ev.getSource()).stop();
                            }
                        } else {
                            currentWidth += 20;
                            if (currentWidth >= MAX_WIDTH) {
                                currentWidth = MAX_WIDTH;
                                isExpanded = true;
                                ((Timer) ev.getSource()).stop();
                            }
                        }

                        historyPanel.setPreferredSize(new Dimension(currentWidth, 0));
                        historyContainer.revalidate();
                        window.revalidate();
                        window.repaint();
                    }
                });
                timer.start();
            }
        });

        displayField = new JTextField("0");
        displayField.setEditable(false);
        displayField.setHorizontalAlignment(JTextField.RIGHT);
        displayField.setFont(new Font("Arial", Font.BOLD, 32));
        displayField.setPreferredSize(new Dimension(0, 70));

        displayField.putClientProperty("FlatLaf.style", "arc: 20; borderWidth: 2");

        JButton button1 = createStyledButton("1");
        JButton button2 = createStyledButton("2");
        JButton button3 = createStyledButton("3");
        JButton button4 = createStyledButton("4");
        JButton button5 = createStyledButton("5");
        JButton button6 = createStyledButton("6");
        JButton button7 = createStyledButton("7");
        JButton button8 = createStyledButton("8");
        JButton button9 = createStyledButton("9");
        JButton button0 = createStyledButton("0");
        JButton buttonDot = createStyledButton(".");
        JButton buttonPlus = createStyledButton("+");
        JButton buttonMinus = createStyledButton("-");
        JButton buttonMultiply = createStyledButton("*");
        JButton buttonDivide = createStyledButton("/");
        JButton buttonEquals = createStyledButton("=");
        JButton buttonClear = createStyledButton("C");
        JButton buttonRandom = createStyledButton("Random");
        JButton buttonSqrt = createStyledButton("√");
        JButton buttonDel = createStyledButton("Del");

        colum1.add(button1);
        colum1.add(button4);
        colum1.add(button7);
        colum1.add(button0);

        colum2.add(button2);
        colum2.add(button5);
        colum2.add(button8);
        colum2.add(buttonDot);

        colum3.add(button3);
        colum3.add(button6);
        colum3.add(button9);
        colum3.add(buttonEquals);

        colum4.add(buttonClear);
        colum4.add(buttonPlus);
        colum4.add(buttonMinus);
        colum4.add(buttonSqrt);

        colum5.add(buttonDel);
        colum5.add(buttonMultiply);
        colum5.add(buttonDivide);
        colum5.add(buttonRandom);

        buttonPanel.add(colum1);
        buttonPanel.add(colum2);
        buttonPanel.add(colum3);
        buttonPanel.add(colum4);
        buttonPanel.add(colum5);

        calcPanel.add(displayField, BorderLayout.NORTH);
        calcPanel.add(buttonPanel, BorderLayout.CENTER);

        window.add(calcPanel, BorderLayout.CENTER);
        window.add(historyContainer, BorderLayout.EAST);

        window.setVisible(true);
    }

    private JButton createStyledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 20));
        btn.setFocusPainted(false);

        btn.putClientProperty("FlatLaf.style", "arc: 25");

        if (text.matches("[+\\-*/=√C]|Random|Del")) {
            btn.setBackground(new Color(14, 43, 81));
            btn.setForeground(Color.WHITE);
        } else {
            btn.setBackground(new Color(60, 64, 67));
            btn.setForeground(Color.WHITE);
        }

        return btn;
    }

    public void setDisplayField(String text) {
        this.displayField.setText(text);
    }

    public String getDisplayField() {
        return this.displayField.getText();
    }

    public void updateHistory(java.util.List<String> historyList) {
        StringBuilder sb = new StringBuilder(" History:\n\n");
        for (String item : historyList) {
            sb.append(" ").append(item).append("\n");
        }
        this.historyField.setText(sb.toString());
    }

    public void setButtonListener(ActionListener listener) {
        attachListenerToPanel(buttonPanel, listener);
    }

    private void attachListenerToPanel(Container container, ActionListener listener) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JButton) {
                ((JButton) comp).addActionListener(listener);
            } else if (comp instanceof Container) {
                attachListenerToPanel((Container) comp, listener);
            }
        }
    }

    public JRootPane getRootPane() {
        return window.getRootPane();
    }
}
